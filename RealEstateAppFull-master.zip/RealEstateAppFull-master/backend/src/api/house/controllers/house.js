'use strict';

/**
 *  house controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::house.house');
